/******************************************************************************
*
* Copyright (C) 2009 - 2014 Xilinx, Inc.  All rights reserved.
*
* Permission is hereby granted, free of charge, to any person obtaining a copy
* of this software and associated documentation files (the "Software"), to deal
* in the Software without restriction, including without limitation the rights
* to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the Software is
* furnished to do so, subject to the following conditions:
*
* The above copyright notice and this permission notice shall be included in
* all copies or substantial portions of the Software.
*
* Use of the Software is limited solely to applications:
* (a) running on a Xilinx device, or
* (b) that interact with a Xilinx device through a bus or interconnect.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
* XILINX  BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF
* OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
* SOFTWARE.
*
* Except as contained in this notice, the name of the Xilinx shall not be used
* in advertising or otherwise to promote the sale, use or other dealings in
* this Software without prior written authorization from Xilinx.
*
******************************************************************************/

/*
 * helloworld.c: simple test application
 *
 * This application configures UART 16550 to baud rate 9600.
 * PS7 UART (Zynq) is not initialized by this application, since
 * bootrom/bsp configures it to baud rate 115200
 *
 * ------------------------------------------------
 * | UART TYPE   BAUD RATE                        |
 * ------------------------------------------------
 *   uartns550   9600
 *   uartlite    Configurable only in HW design
 *   ps7_uart    115200 (configured by bootrom/bsp)
 */

#include <stdio.h>
#include "platform.h"
#include "xil_printf.h"
#include "xil_io.h"
#include "ecdsa_config.h"
#include "ed25519.h"

#define MESSAGE_LENGTH 0x200
#define MESSAGE_START 0x100

#define SIGNATURE_OUT_OFFSET 0x300

#define CONTROL_SIGNAL_OFFSET 0

void external_copy_in(unsigned char *destination_buffer, unsigned int source_address, unsigned int length){
	int i;
	for(i=0; i<length; i++){
		destination_buffer[i] = Xil_In8(source_address + i);
	}
}

void external_copy_out(unsigned char *source_buffer, unsigned int destination_address, unsigned int length){
	int i;
	for(i=0; i<length; i++){
		Xil_Out8(destination_address + i, source_buffer[i]);
	}
}

void load_key_from_storage(unsigned char *key_buffer){
	external_copy_in(key_buffer, STORAGE_BUFFER_BASE + KEY_OFFSET, KEY_LENGTH);
}

void load_pub_from_storage(unsigned char *pub_buffer){
	external_copy_in(pub_buffer, STORAGE_BUFFER_BASE + PUB_OFFSET, PUB_LENGTH);
}

int main()
{
	unsigned char control_signal;
	unsigned char key_buffer[64], pub_buffer[32], signature[64];
	unsigned char local_message_buffer[MESSAGE_LENGTH];

    init_platform();
    //Load private key
    load_key_from_storage(key_buffer);
    //Load public key
    load_pub_from_storage(pub_buffer);

    while(1){
    	print("Starting sign\n\r");
    	//Check if a message is present
    	control_signal = Xil_In8(SHARED_BUFFER_BASE + CONTROL_SIGNAL_OFFSET);
    	if(control_signal | 0x1){
    		print("Message detected\n\r");
    		//If set, copy in the message
    		external_copy_in(local_message_buffer, SHARED_BUFFER_BASE + MESSAGE_START, MESSAGE_LENGTH);
    		//Sign the message
    		ed25519_sign(signature, local_message_buffer, MESSAGE_LENGTH, pub_buffer, key_buffer);
    		//Copy the message out
    		external_copy_out(signature, SHARED_BUFFER_BASE + SIGNATURE_OUT_OFFSET, 64);
    		//Clear the enable signal to indicate finished
    		control_signal |= 0xFE;
    		print("Message signing finished\n\r");
    	}

    }
    cleanup_platform();
    return 0;
}


