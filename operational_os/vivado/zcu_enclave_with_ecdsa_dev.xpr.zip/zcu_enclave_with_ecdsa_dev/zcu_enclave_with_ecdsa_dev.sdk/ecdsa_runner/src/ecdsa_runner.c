#include "xil_io.h"
#include "ed25519.h"

#define SHARED_BUFFER 0xB0010000
#define SHARED_BUFFER_LENGTH 0x4000
#define ECDSA_CONTROL 0x0
#define ECDSA_SIGNATURE 0x100
#define ECDSA_PROGRAM_HASH 0x140
#define ECDSA_DATA 0x160
#define MESSAGE_LENGTH 0x40
#define SECURE_STORAGE 0xA0050000
#define SECURE_STORAGE_LENGTH 0x1000
#define PRIVATE_OFFSET 0x0
#define PUBLIC_OFFSET 0x40

int main(){
	volatile unsigned char *private_key = (unsigned char*)(SECURE_STORAGE + PRIVATE_OFFSET);
	volatile unsigned char *public_key = (unsigned char*)(SECURE_STORAGE + PUBLIC_OFFSET);
	volatile unsigned char *signature = (unsigned char*)(SHARED_BUFFER + ECDSA_SIGNATURE);
	//TODO: for dev, the arm will generate the hash. in future, will do this ourselves by programming the
	//enclave cpu here, rather than having the arm do it
	volatile unsigned char *hash_in = (unsigned char*)(SECURE_STORAGE + 0x60);
	volatile unsigned char *hash = (unsigned char*)(SHARED_BUFFER + ECDSA_PROGRAM_HASH);
//	volatile unsigned char *data = (unsigned char*)ECDSA_DATA;
	int i;
	while(1){
		if(Xil_In32(SHARED_BUFFER + ECDSA_CONTROL) == 0){
			continue;
		}
		//copy the hash into the hash part of the buffer
		for(i=0; i<0x20; i++){
			hash[i] = hash_in[i];
		}
		ed25519_sign((unsigned char*)signature, (unsigned char*)hash, MESSAGE_LENGTH + 0x20, (unsigned char*)public_key, (unsigned char*)private_key);
		Xil_Out32(SHARED_BUFFER + ECDSA_CONTROL, 0);
		Xil_Out32(SHARED_BUFFER + 4, 0xFF);
	}
	return 0;
}

void program_enclave(){
	//1: program dma engine to copy from arm memory to enclave buffer, using a length parameter
	//2: take sha hash of the enclave memory and store the result in a global variable
	//3: reset the enclave cpu
	//4: use this hash in future ecdsa calls
}
