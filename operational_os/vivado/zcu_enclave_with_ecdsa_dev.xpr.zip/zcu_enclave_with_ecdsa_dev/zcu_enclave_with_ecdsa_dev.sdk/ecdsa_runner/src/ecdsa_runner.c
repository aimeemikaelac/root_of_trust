#include "xil_io.h"
#include "ed25519.h"
#include "sha512.h"

#define STORAGE_BUFFER 0xA0050000
#define STORAGE_LENGTH 0x1000

#define ARM_CONTROL_BUFFER 0xB0003000
#define ARM_CONTROL_LENGTH 0x1000

#define ENCLAVE_BUFFER 0xB0004000
#define ENCLAVE_LENGTH 0x1000

#define ENCLAVE_MEMORY 0xB0100000
#define ENCLAVE_MEMORY_LENGTH 0x100000

#define ATTESTATION_CONTROL 0
#define SIGNATURE_OFFSET 0x100
#define HASH_OFFSET 0x140
#define PUBLIC_KEY_OUT 0x180
#define DATA_OFFSET 0x1A0
#define MESSAGE_LENGTH 0xA0
#define PRIVATE_KEY_OUT 0x240
#define REMOTE_SIGNATURE 0x2A0
#define REMOTE_PUBLIC_KEY 0x2E0
#define SHARED_SECRET_OUT 0x300
#define PRIVATE_OFFSET 0x0
#define PUBLIC_OFFSET 0x40

#define HASH_BLOCK_SIZE 0x80
#define PROGRAMMING_DATA_OFFSET 0x100

void generate_attestation(){
	volatile unsigned char *private_key = (unsigned char*)(STORAGE_BUFFER + PRIVATE_OFFSET);
	volatile unsigned char *public_key = (unsigned char*)(STORAGE_BUFFER + PUBLIC_OFFSET);
	volatile unsigned char *signature = (unsigned char*)(ENCLAVE_BUFFER + SIGNATURE_OFFSET);
	volatile unsigned char *hash = (unsigned char*)(ENCLAVE_BUFFER + HASH_OFFSET);
	volatile unsigned char *public_key_out = (unsigned char*)(ENCLAVE_BUFFER + PUBLIC_KEY_OUT);
	volatile unsigned char *private_key_out = (unsigned char*)(ENCLAVE_BUFFER + PRIVATE_KEY_OUT);
	volatile unsigned char *shared_secret = (unsigned char*)(ENCLAVE_BUFFER + SHARED_SECRET_OUT);
	volatile unsigned char *remote_public_key = (unsigned char*)(ENCLAVE_BUFFER + REMOTE_PUBLIC_KEY);
	if(Xil_In32(ENCLAVE_BUFFER + ATTESTATION_CONTROL) == 0){
		return;
	}
	ed25519_create_keypair((unsigned char*)public_key_out, (unsigned char*)private_key_out, (const unsigned char*)hash);
	ed25519_sign((unsigned char*)signature, (unsigned char*)hash, 0x100, (unsigned char*)public_key, (unsigned char*)private_key);
	ed25519_key_exchange((unsigned char*)shared_secret, (const unsigned char*)remote_public_key, (const unsigned char*)private_key_out);
	Xil_Out32(ENCLAVE_BUFFER + ATTESTATION_CONTROL, 0);
	Xil_Out32(ENCLAVE_BUFFER + 4, 0xFF);
	return;
}

void program_enclave(){
	//0x0: start signal
	//0x4: block length
	//0x8: current block ready
	//0xC: current block finished
	//0x10: last block
	//0x14: finished
	//0x100: data, 0x100 bytes
	unsigned int enclave_index = 0, block_length;
//	unsigned int total_length=0;
	int i, iteration = 0;
	volatile unsigned char *enclave = (volatile unsigned char*)ENCLAVE_MEMORY;
	volatile unsigned char *data = (volatile unsigned char*)(ARM_CONTROL_BUFFER + PROGRAMMING_DATA_OFFSET);
	volatile unsigned char *hash_out_final = (volatile unsigned char*)(ENCLAVE_BUFFER + HASH_OFFSET);
//	volatile unsigned char *hash_out_dev = (volatile unsigned char*)(ARM_CONTROL_BUFFER + 0x200);
//	unsigned char hash_buffer[HASH_BLOCK_SIZE];
//	unsigned char hash_out[0x40];
	if(Xil_In32(ARM_CONTROL_BUFFER) == 0){
		return;
	}
	sha512_context context;
	sha512_init(&context);
	while(1){
		//clear finished signal
		Xil_Out32(ARM_CONTROL_BUFFER + 0xC, 0);
		Xil_Out32(ARM_CONTROL_BUFFER + 0x14, 0);
		//wait for the block ready signal
		while(Xil_In32(ARM_CONTROL_BUFFER + 0x8) == 0){
			__asm__("");
			asm("");
		}
		block_length = Xil_In32(ARM_CONTROL_BUFFER + 0x4);
		//copy block to enclave
		for(i=0; i<block_length; i++){
			enclave[enclave_index + i] = data[i];
		}
		sha512_update(&context, (unsigned char*)data, block_length);
		//increment index
		enclave_index += block_length;
//		total_length += block_length;
		//clear the block ready signal
		Xil_Out32(ARM_CONTROL_BUFFER + 0x8, 0);
		//set finished block signal
		Xil_Out32(ARM_CONTROL_BUFFER + 0xC, 0xFF);
		Xil_Out32(ARM_CONTROL_BUFFER + 0x18, iteration);
		iteration++;
		//this was the last block, don't go again
		if(Xil_In32(ARM_CONTROL_BUFFER + 0x10) != 0){
			break;
		}
	}
//	sha512_update(&context, (unsigned char*)enclave, total_length);
	sha512_final(&context, (unsigned char*)hash_out_final);
//	for(i=0; i<0x40; i++){
//		hash_out_final[i] = hash_out[i];
//		hash_out_dev[i] = hash_out[i];
//	}
	Xil_Out32(ARM_CONTROL_BUFFER + 0x14, 0xFF);
	return;
}

int main(){
	//clear the start signals on reset
	Xil_Out32(ARM_CONTROL_BUFFER, 0);
	Xil_Out32(ENCLAVE_BUFFER + ATTESTATION_CONTROL, 0);
	while(1){
		program_enclave();
		generate_attestation();
	}
}
