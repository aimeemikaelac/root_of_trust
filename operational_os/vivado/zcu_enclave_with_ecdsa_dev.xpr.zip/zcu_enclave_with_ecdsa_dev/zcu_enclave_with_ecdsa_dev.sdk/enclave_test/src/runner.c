#include "xil_io.h"
#include "microblaze_protocol_header.h"

void watch_mem_buffer(){

  unsigned int function;
  int i, counter = 0;
  //while true, check for the function
  while(1){
    // Check if a ready signal is set
    //TODO: use this register with a bitmask for more data?
    if(Xil_In32(SHARED_BUFFER_ADDRESS + 0x70) == 0){
      Xil_Out32(SHARED_BUFFER_ADDRESS + 0x90, counter);
      counter++;
      continue;
    }
    function = Xil_In32(SHARED_BUFFER_ADDRESS + 0x60);
    switch(function){

      case 0 :

        toggle_case(

        (unsigned char*)(SHARED_BUFFER_ADDRESS + 256), (unsigned char*)(SHARED_BUFFER_ADDRESS + 272)
        );
        Xil_Out32(SHARED_BUFFER_ADDRESS + 0x80, 0xFF);
      break;

      default :
        continue;
    }
  }
}

int main(){
//  volatile unsigned char *temp = (volatile unsigned char*)(SHARED_BUFFER_ADDRESS + 0x90);
//  Xil_Out32(SHARED_BUFFER_ADDRESS + 0x90, 0xFF);
//  temp[0] = 0xFF;
  watch_mem_buffer();
  return 0;
}
