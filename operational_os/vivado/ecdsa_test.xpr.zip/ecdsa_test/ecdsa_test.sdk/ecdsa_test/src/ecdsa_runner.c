#include "xparameters.h"
//#include "xil_printf.h"
#include "xil_io.h"
#include "ed25519.h"

#define SHARED_BUFFER 0xA0010000

int main(){
	unsigned char *public_key, *private_key, *seed, *data, *data_out, *control, *buffer;
	buffer = (unsigned char*)SHARED_BUFFER;
	seed = buffer;
	public_key = (unsigned char*)(SHARED_BUFFER + 32);
	private_key = (unsigned char*)(SHARED_BUFFER + 64);
	data = (unsigned char*)(SHARED_BUFFER + 128);
	data_out = (unsigned char*)(SHARED_BUFFER + 128 + 0x100);
	control = (unsigned char*)(SHARED_BUFFER + 128 + 0x200);

	int i;
	control[0] = 0;
	print("Starting");
	for(i=0; i<0x280; i++){
		buffer[i] = 0xFF;
	}
//	for(i=0; i<32; i++){
//		public_key[i] = Xil_In8(SHARED_BUFFER + i);
//	}
//	for(i=0; i<64; i++){
//		private_key[i] = Xil_In8(SHARED_BUFFER + 32 + i);
//	}
	ed25519_create_keypair(public_key, private_key, seed);
//	for(i=0; i<0x100; i++){
//		data[i] = Xil_In8(SHARED_BUFFER + 32 + 64 + i);
//	}
	ed25519_sign(data_out, data, 0x100, public_key, private_key);
//	for(i=0; i<0x1000; i++){
//		seed[i] = 0xFF;
//	}
	print("Finished");
	control[0] = 0xFF;
}
