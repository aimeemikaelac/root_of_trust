/*
 * ecdsa_config.h
 *
 *  Created on: Oct 17, 2017
 *      Author: michael
 */

#ifndef SRC_ECDSA_CONFIG_H_
#define SRC_ECDSA_CONFIG_H_

#define SHARED_BUFFER_BASE 0xA0040000
#define SHARED_BUFFFER_LENGTH 0x8000

#define STORAGE_BUFFER_BASE 0xC2000000
#define STORAGE_BUFFER_LENGTH 0x8000

#define KEY_OFFSET 0
#define KEY_LENGTH 64
#define PUB_OFFSET 64
#define PUB_LENGTH 32

#endif /* SRC_ECDSA_CONFIG_H_ */
