/******************************************************************************
*
* Copyright (C) 2009 - 2014 Xilinx, Inc.  All rights reserved.
*
* Permission is hereby granted, free of charge, to any person obtaining a copy
* of this software and associated documentation files (the "Software"), to deal
* in the Software without restriction, including without limitation the rights
* to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the Software is
* furnished to do so, subject to the following conditions:
*
* The above copyright notice and this permission notice shall be included in
* all copies or substantial portions of the Software.
*
* Use of the Software is limited solely to applications:
* (a) running on a Xilinx device, or
* (b) that interact with a Xilinx device through a bus or interconnect.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
* XILINX  BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF
* OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
* SOFTWARE.
*
* Except as contained in this notice, the name of the Xilinx shall not be used
* in advertising or otherwise to promote the sale, use or other dealings in
* this Software without prior written authorization from Xilinx.
*
******************************************************************************/

/*
 * helloworld.c: simple test application
 *
 * This application configures UART 16550 to baud rate 9600.
 * PS7 UART (Zynq) is not initialized by this application, since
 * bootrom/bsp configures it to baud rate 115200
 *
 * ------------------------------------------------
 * | UART TYPE   BAUD RATE                        |
 * ------------------------------------------------
 *   uartns550   9600
 *   uartlite    Configurable only in HW design
 *   ps7_uart    115200 (configured by bootrom/bsp)
 */

#include <stdio.h>
#include <stdlib.h>
#include "xparameters.h"
#include "platform.h"
#include "xil_printf.h"
#include "xaxi_to_128_bit.h"

#define DELAY 100
#define AXI_to_128_BASE 0xB0010000


int main()
{
	unsigned int rand_num, seed=0;
	int i;

    init_platform();

    while(1){
    	print("Hello World\n\r");
//    }

//    while(1){
//    	rand_num = seed;
//    	srand(seed);
    	print("ABABAB\n\r");

//		rand_num = rand();
		XAxi_to_128_bit_WriteReg(AXI_to_128_BASE, 0x10, seed);
//		xil_printf("%d", rand_num);

//		rand_num = rand();
		XAxi_to_128_bit_WriteReg(AXI_to_128_BASE, 0x14, seed << 8);
//		xil_printf("%d", rand_num);

//		rand_num = rand();
		XAxi_to_128_bit_WriteReg(AXI_to_128_BASE, 0x18, seed << 16);
//		xil_printf("%d", rand_num);

//		rand_num = rand();
		XAxi_to_128_bit_WriteReg(AXI_to_128_BASE, 0x1C, seed << 24);
//		xil_printf("%d\n\r", rand_num);

		print("YZYZYZ\n\r");
//		for(i=0; i<DELAY; i++){
//			seed = seed + rand_num % 1000000000;
//		}
		seed = (seed + 1) % 0x100;
    }

    cleanup_platform();
    return 0;
}
