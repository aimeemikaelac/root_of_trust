#ifndef MICROBLAZE_PROTOCOL_HEADER_H
#define MICROBLAZE_PROTOCOL_HEADER_H

#ifdef __cplusplus
extern "C" {
#endif

#define SHARED_BUFFER_ADDRESS 0xA0040000
#define SHARED_BUFFER_SIZE 0x4000


void toggle_case(unsigned char *input, unsigned char *output);


#ifdef __cplusplus
}
#endif
#endif
