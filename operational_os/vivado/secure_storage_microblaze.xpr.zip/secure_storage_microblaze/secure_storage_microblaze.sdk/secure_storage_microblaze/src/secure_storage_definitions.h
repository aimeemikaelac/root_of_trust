/*
 * secure_storage_definitions.h
 *
 *  Created on: Oct 15, 2017
 *      Author: michael
 */

#ifndef SRC_SECURE_STORAGE_DEFINITIONS_H_
#define SRC_SECURE_STORAGE_DEFINITIONS_H_

#include <stdio.h>
#include <stdlib.h>
#include "xparameters.h"
#include "platform.h"
#include "xil_printf.h"
#include "xil_io.h"


#define WRITE_DELAY 0x10000
//#define AXI_to_128_BASE 0xB0010000

//Define the ENABLE_WRITES flag to enable signaling the CPU to write the storage buffer to the SD card
//#define ENABLE_WRITES

#ifdef ENABLE_WRITES
//Address to write 1 to signal the CPU to store storage buffer
#define CPU_WRITE_STORAGE 0
//Address to read to signal that the CPU write is complete
#define CPU_WRITE_COMPLETE 0
#endif

#define STORAGE_BUFFER 0xB0004000
#define STORAGE_LENGTH 0x4000

#define NUM_DEVICES 1


//List of device names
char *device_names[] = {
		"ECDSA"
};

//List of device data lengths in bytes. Should be multiple of 4 bytes (32-bit words)
unsigned int device_data_lengths[] = {
		4
};

//List of device data locations in the secure storage buffer
unsigned int device_source_addresses[] = {
		0x0
};

//List of memory-mapped I/O addresses to write the data to
unsigned int device_destination_addresses[] = {
		0xB0010010
};

//List of memory-mapped signals to watch for a write request. 0 to ignore for a device
unsigned int device_watch_addresses[] = {
		0
};

//List of memory-mapped regions to read data from for a write. 0 to ignore for a device
unsigned int device_write_addresses[] = {
		0
};


#endif /* SRC_SECURE_STORAGE_DEFINITIONS_H_ */
