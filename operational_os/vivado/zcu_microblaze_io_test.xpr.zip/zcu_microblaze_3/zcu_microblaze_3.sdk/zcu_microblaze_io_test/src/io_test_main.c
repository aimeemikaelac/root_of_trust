#include <stdio.h>
#include "xparameters.h"
#include "platform.h"
#include "xil_printf.h"
#include "xgpio_l.h"

//#define GPIO_IN XPAR_GPIO_0_DEVICE_ID
//#define GPIO_OUT XPAR_GPIO_2_DEVICE_ID
#define GPIO_IN_BASE 0x40000000
#define GPIO_OUT_BASE 0x40020000

#define DELAY     10000000

int main()
{
	int delay_count;

    init_platform();

    print("ababababab\n\r");

	//Read from input gpio

	u32 in_1_val = XGpio_ReadReg(GPIO_IN_BASE, XGPIO_DATA_OFFSET);
	u32 in_2_val = XGpio_ReadReg(GPIO_IN_BASE, XGPIO_DATA2_OFFSET);

	for (delay_count = 0; delay_count < DELAY; delay_count++);

	print("dddddddddddd\n\r");

	//write to output gpio
	XGpio_WriteReg(GPIO_OUT_BASE, XGPIO_DATA_OFFSET, in_1_val);
	XGpio_WriteReg(GPIO_OUT_BASE, XGPIO_DATA2_OFFSET, in_2_val);

	for (delay_count = 0; delay_count < DELAY; delay_count++);

	print("eeeeeeeeeeee\n\r");

    cleanup_platform();
    return 0;
}
